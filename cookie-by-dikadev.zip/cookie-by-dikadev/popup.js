"use strict";
// v1.2: baca cookie LANGSUNG per domain via chrome.cookies.getAll({}),
// tanpa peduli tab mana yang aktif (lebih stabil di Kiwi Android).
const out = document.getElementById("out");
const site = document.getElementById("site");
const info = document.getElementById("info");
const domlist = document.getElementById("domlist");

function showCookies(domain, cookies, btn) {
  domlist.querySelectorAll(".dombtn").forEach((x) => x.classList.remove("sel"));
  if (btn) btn.classList.add("sel");
  site.textContent = "Domain: " + domain;
  if (!cookies.length) {
    out.value = "";
    info.textContent = "0 cookie — pastikan sudah login di domain itu.";
    return;
  }
  // Cookie sesi Shopee (SPC_/csrftoken) di depan biar gampang dicek
  const rank = (n) => (/^(SPC_|csrftoken)/.test(n) ? 0 : 1);
  const sorted = cookies.slice().sort((a, b) => rank(a.name) - rank(b.name));
  out.value = sorted.map((c) => c.name + "=" + c.value).join("; ");
  info.textContent = cookies.length + " cookie terbaca.";
}

chrome.cookies.getAll({}, (all) => {
  const byDomain = {};
  (all || []).forEach((c) => {
    const d = String(c.domain || "").replace(/^\./, "");
    if (!d) return;
    (byDomain[d] = byDomain[d] || []).push(c);
  });
  const names = Object.keys(byDomain).sort((a, b) => {
    const sa = /shopee/i.test(a) ? 0 : 1;
    const sb = /shopee/i.test(b) ? 0 : 1;
    if (sa !== sb) return sa - sb;
    return byDomain[b].length - byDomain[a].length;
  });
  if (!names.length) {
    site.textContent = "Tidak ada cookie tersimpan di browser.";
    return;
  }
  names.forEach((d) => {
    const b = document.createElement("button");
    b.className = "dombtn";
    b.dataset.d = d;
    b.textContent = d.replace(/^www\./, "") + " (" + byDomain[d].length + ")";
    b.onclick = () => showCookies(d, byDomain[d], b);
    domlist.appendChild(b);
  });
  // Auto-pilih: shopee.co.id persis (bukan seller), lalu shopee.* lain, lalu domain pertama
  const autoName =
    names.find((n) => n === "shopee.co.id") ||
    names.find((n) => /shopee/i.test(n) && !/seller/i.test(n)) ||
    names.find((n) => /shopee/i.test(n)) ||
    names[0];
  const autoBtn = domlist.querySelector('.dombtn[data-d="' + autoName + '"]');
  if (autoBtn) autoBtn.click();
});

document.getElementById("copy").onclick = async () => {
  const t = out.value.trim();
  if (!t) { info.textContent = "Nggak ada yang bisa disalin."; return; }
  try {
    await navigator.clipboard.writeText(t);
  } catch (e) {
    out.focus(); out.select();
    document.execCommand("copy");
  }
  info.innerHTML = '<span id="ok">✅ Tersalin! Tempel ke bot.</span>';
};
